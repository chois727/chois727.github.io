A Pen created at CodePen.io. You can find this one at http://codepen.io/davidicus/pen/pvObpV.

 Once again using the input:checked technique to trigger a horizontal scroll. No JS required.